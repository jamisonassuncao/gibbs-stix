HeFESTo by L. Stixrude and C. Lithgow-Bertelloni, 2005-

Citations.  If you use HeFESTo results in a publication, please cite the following papers:

(1) Stixrude, L. and C. Lithgow-Bertelloni, Thermodynamics of mantle minerals: 1. Physical properties, Geophysical Journal International, 162, 610-632, 2005.
(2) Stixrude, L. and C. Lithgow-Bertelloni, Thermodynamics of mantle minerals II, Phase equilibria, Geophysical Journal International, 184, 1180-1213, 2011.
(3) The citation to the parameter file that you have chosen.

***** WARNING *****  

This version is for testing purposes only, which means we grant the right to download, compile, and run the software, but do not grant the right to redistribute modified versions of the software either in compiled or in source-code form. If you have questions about the software, suggestions for improvements, or would like to ask for additional permissions or data files, please contact the authors:

Lars Stixrude: lstixrude@epss.ucla.edu
Carolina Lithgow-Bertelloni: clb@epss.ucla.edu
